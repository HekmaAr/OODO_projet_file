from odoo import fields, models


class Book(models.Model):
    _inherit = "library.book"

    is_available = fields.Boolean("Is Available?")
    livrable = fields.Boolean("Deliverable?")
    isbn = fields.Char(help="Use a valid ISBN-13 or ISBN-10.")
    publisher_id = fields.Many2one('res.partner', string="Publisher", index=True)

    def _check_isbn(self):
        self.ensure_one()
        digits = [int(x) for x in self.isbn if x.isdigit()]
        if len(digits) == 10:
            ponderators = [1, 2, 3, 4, 5, 6, 7, 8, 9]
            total = sum(a * b for a, b in zip(digits[:9], ponderators))
            check = 11 - (total % 11)
            if check == 10:
                check = 'X'
            return str(check) == str(digits[-1])
        elif len(digits) == 13:
            ponderators = [1, 3] * 6
            total = sum(a * b for a, b in zip(digits[:12], ponderators))
            check = 10 - (total % 10)
            if check == 10:
                check = 0
            return str(check) == str(digits[-1])
        else:
            return False
